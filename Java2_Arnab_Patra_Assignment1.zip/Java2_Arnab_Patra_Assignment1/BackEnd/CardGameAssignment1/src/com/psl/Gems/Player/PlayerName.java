package com.psl.Gems.Player;

public class PlayerName {
public static String playerName1;
public static String playerName2;
public PlayerName()
{
	
}
public static String getPlayerName1() {
	return playerName1;
}
public static void setPlayerName1(String playerName1) {
	PlayerName.playerName1 = playerName1;
}
public static String getPlayerName2() {
	return playerName2;
}
public static void setPlayerName2(String playerName2) {
	PlayerName.playerName2 = playerName2;
}

}
