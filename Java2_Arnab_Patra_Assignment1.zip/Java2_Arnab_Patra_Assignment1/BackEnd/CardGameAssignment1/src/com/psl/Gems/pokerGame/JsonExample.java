package com.psl.Gems.pokerGame;

//import org.json.*;
import org.json.JSONObject;
//import org.json.JSONObject;

public class JsonExample {
    public static void main(String[] args) {
        // Create a new JSON object
        JSONObject obj = new JSONObject();

        // Add key-value pairs to the object
//        obj.put("name", "John Doe");
//        obj.put("age", 30);
//        obj.put("city", "New York");
//
//        // Print the JSON object
//        System.out.println(obj);
    }
}
