package com.psl.Gems.pokerGame;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
//This should have been  com.psl.gems.client.TestClient class
import java.util.ArrayList;
import java.util.Random;

import com.psl.Gems.Player.Game;
import com.psl.Gems.Player.Player;
import com.psl.Gems.Player.PlayerName;
public class Main {
public static void main(String[] args) throws IOException
{	
	Game g1=new Game();
	g1.play();
}
}
